# spring-boot-security-oauth2
This article aims to provide a working example of spring boot security oauth2. To get started with this project just checkout the project
and set up the database configuration as per application.properties and run Application.java as a java application and you are done.

This project uses
1. Spring Boot 2.4.4
2. Java 8
3. MySql