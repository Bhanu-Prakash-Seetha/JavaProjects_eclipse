package com.Auth.Auth_Security.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Auth.Auth_Security.modal.Users;
@Repository
public interface UserDetailRepository extends JpaRepository<Users, Integer>{
	
	public Optional<Users> findByName(String name);
}
