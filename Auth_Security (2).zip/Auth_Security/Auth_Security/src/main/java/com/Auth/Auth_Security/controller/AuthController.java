package com.Auth.Auth_Security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Auth.Auth_Security.modal.JwtRequest;
import com.Auth.Auth_Security.modal.JwtResponse;
import com.Auth.Auth_Security.modal.JwtResponse_token;
import com.Auth.Auth_Security.modal.Users;
import com.Auth.Auth_Security.security.JwtHelper;
import com.Auth.Auth_Security.service.CustomUserService;

@RestController
@RequestMapping("/auth")
public class AuthController {
	@Autowired
	private CustomUserService userDetailService;

	@Autowired
	private AuthenticationManager authManager;

	@Autowired
	private JwtHelper helper;

	/*
	 * @PostMapping("/login") public ResponseEntity<JwtResponse> login(@RequestBody
	 * JwtRequest request) { this.doAuthenticate(request.getUsername(),
	 * request.getPassword()); UserDetails userDetails =
	 * userDetailService.loadUserByUsername(request.getUsername()); //Users
	 * userDetails = (Users)
	 * userDetailService.loadUserByUsername(request.getUsername());
	 * System.out.println(userDetails); String token =
	 * this.helper.generateToken(userDetails); JwtResponse response = new
	 * JwtResponse(); response.setToken(token);
	 * response.setUsername(userDetails.getUsername()); return new
	 * ResponseEntity<>(response, HttpStatus.OK);
	 * 
	 * }
	 */
	@PostMapping("/login")
	public ResponseEntity<JwtResponse_token> login(@RequestBody JwtRequest request) {
		this.doAuthenticate(request.getUsername(), request.getPassword());
		UserDetails userDetails = userDetailService.loadUserByUsername(request.getUsername());
		//Users userDetails = (Users) userDetailService.loadUserByUsername(request.getUsername());
		System.out.println(userDetails);
		String token = helper.generateToken(userDetails);
		JwtResponse_token response = new JwtResponse_token();
		response.setToken(token);
		response.setUsername(userDetails.getUsername());
		return new ResponseEntity<>(response, HttpStatus.OK);

	}
	public void doAuthenticate(String username, String password) {
		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(username,
				password);
		try {
			authManager.authenticate(authentication);
		} catch (BadCredentialsException e) {
			throw new BadCredentialsException("invalid credentials");
		}
	}

	@ExceptionHandler(BadCredentialsException.class)
	public String exceptionHandler() {
		return "Credentials invalid";
	}
}
