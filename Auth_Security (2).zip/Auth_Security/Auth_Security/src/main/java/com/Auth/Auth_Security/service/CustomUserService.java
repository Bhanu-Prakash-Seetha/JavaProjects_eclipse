package com.Auth.Auth_Security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.Auth.Auth_Security.modal.Users;
import com.Auth.Auth_Security.repo.UserDetailRepository;
@Service
public class CustomUserService implements UserDetailsService{
	@Autowired
	UserDetailRepository userDetaiRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		Users user=userDetaiRepo.findByName(username).orElseThrow(()-> new RuntimeException("no user found !!"));
		return user;
	}

}
