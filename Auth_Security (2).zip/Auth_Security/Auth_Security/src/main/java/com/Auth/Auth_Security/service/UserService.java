package com.Auth.Auth_Security.service;


import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.Auth.Auth_Security.modal.Users;
import com.Auth.Auth_Security.repo.UserDetailRepository;

@Service
public class UserService {
	@Autowired
	UserDetailRepository userDetailRepo;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	//List<Users> database = new ArrayList<>();
	/*
	 * public UserService(){ database.add(new
	 * Users(UUID.randomUUID().getMostSignificantBits(),"Bhanu","ASE"));
	 * database.add(new
	 * Users(UUID.randomUUID().getMostSignificantBits(),"Prakash","ASE"));
	 * database.add(new
	 * Users(UUID.randomUUID().getMostSignificantBits(),"Supriya","Linuxdev"));
	 * database.add(new
	 * Users(UUID.randomUUID().getMostSignificantBits(),"Minji","Idol")); }
	 */
	
	public List<Users> getUsers() {
		List<Users> database = userDetailRepo.findAll();
		return database;
	}
	
	public void create_user(Users user) {
		Random random =new Random();
		int randomNumber = 100000 + random.nextInt(900000);
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		user.setUserId(randomNumber);
		userDetailRepo.save(user);
	}
	
}
