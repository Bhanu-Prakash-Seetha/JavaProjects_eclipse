package com.Auth.Auth_Security;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthSecurityApplicationTests {

//	@Test
	void contextLoads() {
	}

}
