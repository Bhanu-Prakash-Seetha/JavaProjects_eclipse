package com.crudOps.junit;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.crudOps.junit.modal.UserDetail;

@SpringBootTest
@RunWith(SpringRunner.class)
public class JunitTestOnController extends AbstractTest{
	@Before
	public void setup() {
		super.setup();
	}
	
	@Test
	public void insertData() throws Exception {
		String uri = "/api/save";
		UserDetail user = new UserDetail();
		user.setId(19);
		user.setName("Prakash");
		String inputJson = super.maptoJson(user);
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson)).andReturn(); 
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200,status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println(inputJson);
		System.out.println(content);
		System.out.println("Status code: "+status);
		assertEquals(content,"sucessfull");
	}
	
	@Test
	public void getAllUsers() throws Exception {
		String uri = "/api/getAll";
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
		int Status = result.getResponse().getStatus();
		System.out.println("Status code for get op: "+Status);
		String content = result.getResponse().getContentAsString();
		System.out.println(result);
		System.out.println(content);
		UserDetail[] userData = super.mapfromJson(content, UserDetail[].class);
		assertTrue(userData.length>0);
	}
	
	@Test
	public void testUpdation() throws Exception {
		String uri = "/api/update/2";
		UserDetail user = new UserDetail();
		user.setId(2);
		user.setName("Miyawaki sakura");
		String updateJson = super.maptoJson(user);
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(updateJson)).andReturn();
		int status = result.getResponse().getStatus();
		System.out.println("Status code: "+status);
		assertEquals(200,status);
	}
	
	@Test
	public void testDeletion() throws Exception {
		String uri = "/api/delete/19";
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete(uri)).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
		int val = result.getResponse().getStatus();
		System.out.println("status code delete: "+val);
		assertEquals(200,val);
	}
}
