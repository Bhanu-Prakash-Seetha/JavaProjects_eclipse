package com.crudOps.junit;


import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.crudOps.junit.dao.CrudRepository;
import com.crudOps.junit.modal.UserDetail;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CrudJunittestApplicationTests {

    @Autowired
    private CrudRepository crudRepo;
    
    private UserDetail user;

    @BeforeAll
    public void setup() {
        user = new UserDetail();
        System.out.println("Setting up testcase");
    } 
    /**Insertion*/
    @Test
    public void testInsertion() {
    	user = new UserDetail(6,"chaewon");
    	UserDetail newUser = crudRepo.save(user);
    	System.out.println(newUser+" Inserted");
    	Assertions.assertThat(newUser).isNotNull();
    	
    }
    
    /** Crud operation testing
     * For Reading*/
    @Test
    public void testGetOperation() {
        List<UserDetail> ls = crudRepo.findAll();
        System.out.println(ls +" Fetched");
        Assertions.assertThat(ls.size()).isGreaterThan(0);
    }  
    /**Update Record*/
    @Test
    public void testUpdateUser() {
    	user = new UserDetail();
    	Optional<UserDetail> existingUser = crudRepo.findById(5);
    	if(existingUser!=null) {
    		UserDetail users = existingUser.get();
    		users.setName("Hong eunchae");
    		crudRepo.save(users);
    		System.out.println(users+" Updated");
    		Assertions.assertThat(users).isNotNull();
    		//user.setName();
    	}
    	
    }
    
    
    /**delete Record*/
    //@Test
    public void testDeleteRecord() {
    	user = new UserDetail();
    	crudRepo.deleteById(3);
    	System.out.println("Deleted");
    	Assertions.assertThat(crudRepo.findById(3)).isEmpty();
    }
    
    
}
