package com.crudOps.junit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudJunittestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudJunittestApplication.class, args);
	}

}
