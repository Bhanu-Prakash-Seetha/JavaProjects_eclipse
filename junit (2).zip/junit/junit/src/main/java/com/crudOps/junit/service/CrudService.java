package com.crudOps.junit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crudOps.junit.dao.CrudRepository;
import com.crudOps.junit.modal.UserDetail;
@Service
public class CrudService {
	@Autowired
	private CrudRepository crudRepository;

	public String insertRecord(UserDetail user) {
		// TODO Auto-generated method stub
		 UserDetail a = crudRepository.save(user);
		 System.out.println(a);
		 return "Sucess";
	}

	public List<UserDetail> getAllusers() {
		// TODO Auto-generated method stub
		return crudRepository.findAll();
	}

	public UserDetail updateRecord(int id,UserDetail user) {
		// TODO Auto-generated method stub
		Optional<UserDetail> newUser = crudRepository.findById(id);
		if(newUser!=null) {
			UserDetail existinguser = newUser.get();
			existinguser.setName(user.getName());
			System.out.println("updated");
			return crudRepository.save(existinguser);
		}
		else {
			return null;
		}
	}

	public void deleteRecord(int id) {
		// TODO Auto-generated method stub\
		crudRepository.deleteById(id);
	}

	
	

}
