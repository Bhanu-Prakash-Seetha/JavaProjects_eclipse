package com.crudOps.junit.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.crudOps.junit.modal.UserDetail;
@Repository
public interface CrudRepository extends JpaRepository<UserDetail, Integer>{

}
