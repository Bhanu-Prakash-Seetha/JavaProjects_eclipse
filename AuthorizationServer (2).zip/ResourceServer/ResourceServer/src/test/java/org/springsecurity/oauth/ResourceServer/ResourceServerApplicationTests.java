package org.springsecurity.oauth.ResourceServer;

//import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResourceServerApplicationTests {

	//@Test
	void contextLoads() {
	}

}
