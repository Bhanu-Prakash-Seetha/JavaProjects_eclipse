package org.springsecurity.oauth.AuthorizationServer;

//import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationServerApplicationTests {

	//@Test
	void contextLoads() {
	}

}
