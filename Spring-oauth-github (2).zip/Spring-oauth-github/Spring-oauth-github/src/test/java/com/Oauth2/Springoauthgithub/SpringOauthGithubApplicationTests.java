package com.Oauth2.Springoauthgithub;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringOauthGithubApplicationTests {

	//@Test
	void contextLoads() {
	}

}
