package com.infinite.crudops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudopsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudopsApplication.class, args);
	}

}
