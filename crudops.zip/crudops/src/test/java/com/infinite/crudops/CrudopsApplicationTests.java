package com.infinite.crudops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudopsApplicationTests {

	@Test
	void contextLoads() {
	}

}
