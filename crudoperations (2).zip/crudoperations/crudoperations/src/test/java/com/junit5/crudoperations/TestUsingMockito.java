package com.junit5.crudoperations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import com.junit5.crudoperations.dao.EmployeeRepo;
import com.junit5.crudoperations.modal.Employee;
import com.junit5.crudoperations.service.EmployeeService;
@SpringBootTest
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
public class TestUsingMockito {
	@Mock
	EmployeeRepo empRepo;
	
	@InjectMocks
	EmployeeService empService;

	private Employee employee;
	/**
	 * Test on Saving employees data in sql
	 * */
	@Test
	public void testCreateEmployee__usingMockito() {
		Employee emp = new Employee(19,"Sujith","Developer");
		when(empRepo.save(emp)).thenReturn(emp);
		//now service 
		
		Employee createdEmp = empService.insertEmployeeDetails(emp);
		assertEquals(emp,createdEmp);
		verify(empRepo,times(1)).save(emp);
		
	}
	/**
	 * Test on Getting all Employees data
	 */
	@Test
	public void testgettingemployess__usingMockito() {
		List<Employee> list = empService.getAllEmployees();
		//when(empRepo.findAll()).thenReturn(list);
		System.out.println("fetched data : "+list);
		assertNotNull(list);
		//verify(empRepo,times(1)).findAll();
	}
	/**
	 * Test on Getting the employee data based on specific id
	 * */
	@RepeatedTest(4)
	public void testGettingById_usingMockito() {
		//Employee emp = empService.getById(5, employee);
		//assertNotNull(emp);
		//when(empRepo.findById(4)).then
		Employee emp = new Employee(5,"supriya","QA");
		when(empRepo.findById(5)).thenReturn(Optional.of(emp));
		Employee retrivedEmp = empService.getById(5, emp);
		System.out.println("fetched by id : "+retrivedEmp);
		assertEquals(emp,retrivedEmp);
	}
	//@Test
	public void testUpdateEmpusingMockito() {
		/*
		 * Employee employee1 = new Employee(5,"Supriyak","Sr.QA"); Employee newEmp =
		 * empService.update(5, employee1);
		 * when(empRepo.findById(5)).thenReturn(Optional.ofNullable(employee1));
		 * when(empRepo.save(employee1)).thenReturn(employee1);
		 * 
		 * Employee updatedEmployee = empService.update(5, newEmp);
		 * assertNotNull(updatedEmployee);
		 */
		Employee employee1 = new Employee(5,"supriya","QA");
		when(empRepo.findById(5)).thenReturn(Optional.of(employee1));
		Employee updatedEmp = new Employee(5,"SupriyaKodekanti","Chief.QA");
		empService.update(5,updatedEmp);
		verify(empRepo,times(1)).save(updatedEmp);
		assertNotNull(updatedEmp);
	}
	//@DisplayName("Deletion methods testing")
	//@Test
	public void testDeletion_usingMockito() {
		//when(empRepo.delete(employee))
		/*
		 * when(empRepo.findById(3)).thenReturn(Optional.empty()); empService.delete(3);
		 * verify(empRepo).deleteById(3);
		 * assertEquals(Optional.empty(),empRepo.findById(3));
		 */
		doNothing().when(empRepo).deleteById(3);
		empService.delete(3);
		verify(empRepo,times(1)).deleteById(3);
	    
	}
}
