package com.junit5.crudoperations;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.junit5.crudoperations.dao.EmployeeRepo;
import com.junit5.crudoperations.modal.Employee;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class CrudoperationsApplicationTests {
	@Autowired
	private EmployeeRepo empRepo;

	//TestFactory using Stream
	//@TestFactory
	public Stream<DynamicTest> testInsertions() {
		return Stream.of(DynamicTest.dynamicTest("create a employee", () -> {
			Employee newEmp = new Employee(3, "Nehasri", "test engineer");
			empRepo.save(newEmp);
			assertNotNull(newEmp.getId());
		}),
				DynamicTest.dynamicTest("create a employee 2",()->{
					Employee newEmp1 = new Employee(4, "subhash", "engineer");
					empRepo.save(newEmp1);
					assertNotNull(newEmp1.getId());

				})
		);

	}
	
	//Using testFactory for list
	//@TestFactory
	public List<DynamicTest> testForInsertion(){
		Employee newemployee = new Employee();
		List<DynamicTest> tests = new ArrayList<DynamicTest>();
		tests.add(DynamicTest.dynamicTest("create insert1", ()->{
			newemployee.setId(5);
			newemployee.setName("supriya");
			newemployee.setRole("QA");
			empRepo.save(newemployee);
		}));
		
		tests.add(DynamicTest.dynamicTest("create insert2", ()->{
			newemployee.setId(6);
			newemployee.setName("prasad");
			newemployee.setRole("Linux developer");
			empRepo.save(newemployee);
		}));
		
		return tests;
	}
	
	
	//parameterized test
	@ParameterizedTest
	@CsvSource({
		"7,'siddiq','Bizx'",
		"8,'anil','Bizx'"
	})
	public void createEmployee(int id,String name,String role) {
		Employee newEmp = new Employee(id,name,role);
		assertTrue(empRepo.save(newEmp)!=null);
		assertNotNull(newEmp.getId());
		
	}
	
	@RepeatedTest(3)
	public void testReadData() {
		List<Employee> employees = empRepo.findAll();
		assertNotNull(employees);
	}
	//@Test
	public void testToDeleteRecord() {
		empRepo.deleteById(10);
		assertThat(empRepo.findById(10)).isEmpty();
	}
	
	//Delete operation in Stream
	@TestFactory
	public Stream<DynamicTest> deleteOp(){
		return Stream.of(DynamicTest.dynamicTest("Delete Operation", ()->{
			Optional<Employee> dEmp = empRepo.findById(1);
			Employee getEmp = dEmp.get();
			empRepo.delete(getEmp);
		}));
	}
	
	
	
	
	@Tag("update")
	@TestFactory
	public List<DynamicTest> testForUpdation(){
		Employee emp = new Employee();
		List<DynamicTest> tests = new ArrayList<DynamicTest>();
		Optional<Employee> preemployee = empRepo.findById(14);
		if(preemployee!=null) {
			Employee newEmp1= preemployee.get();
			newEmp1.setRole("Bussiness excellence");
			empRepo.save(newEmp1);
			assertNotNull(newEmp1);
		}
		return tests;
	}
	
	

}
