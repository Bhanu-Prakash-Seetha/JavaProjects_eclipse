package com.junit5.crudoperations;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.web.JsonPath;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.junit5.crudoperations.controller.JunitTestController;
import com.junit5.crudoperations.modal.Employee;
import com.junit5.crudoperations.service.EmployeeService;

@ExtendWith(MockitoExtension.class)
@WebMvcTest(JunitTestController.class)
class TestControllerByMockito {
	@Autowired
	MockMvc mockmvc;

	@MockBean
	private EmployeeService empSer;
	
	
	ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();

	@Test
	public void testCreateEmployee_byMockito() throws Exception {

		Employee newEmp = new Employee(19, "John", "Developer");
		//Employee savedEmp = new Employee(19, "John", "Developer");
		String json = ow.writeValueAsString(newEmp);
		when(empSer.insertEmployeeDetails(any(Employee.class))).thenReturn(newEmp);
		// objmapper.writeValueAsString(newEmp);
		MvcResult res = mockmvc.perform(MockMvcRequestBuilders.post("/api/save")
				.content(json)
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(MockMvcResultMatchers.status().isCreated()).andReturn();
		int status = res.getResponse().getStatus();
		//verify(empSer).insertEmployeeDetails(newEmp);
		assertThat(newEmp.getId()).isNotNull();
		assertThat(201).isEqualTo(status);
	}
	
	@RepeatedTest(4)
	public void testGetAllEmp_controller() throws Exception {
		MvcResult result = mockmvc.perform(MockMvcRequestBuilders.get("/api/getAllEmployees").contentType("application/json")).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
		int status = result.getResponse().getStatus();
		assertThat(200).isEqualTo(status);
	}
	
	@Test
	public void testUpdateController() throws Exception {
		String uri = "/api/update/5";
		Employee employee= new Employee();
		employee.setName("SupriyaK");
		String json=ow.writeValueAsString(employee);
		when(empSer.update(5, employee)).thenReturn(employee);
		//then
		MvcResult result =mockmvc.perform(MockMvcRequestBuilders.put(uri).content(json).contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200,status);
	}
	@Test
	public void testDeletion_usingMockito() throws Exception {
		String uri ="/api/delete/21";
		MvcResult res= mockmvc.perform(MockMvcRequestBuilders.delete(uri).contentType("application/json")).andExpect(MockMvcResultMatchers.status().isAccepted()).andReturn();
		int status = res.getResponse().getStatus();
		
		assertThat(202).isEqualTo(status);
	}
}
