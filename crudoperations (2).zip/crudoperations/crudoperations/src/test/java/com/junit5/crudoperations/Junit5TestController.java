package com.junit5.crudoperations;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.RepeatedTest;
//import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.junit5.crudoperations.modal.Employee;
@ExtendWith(SpringExtension.class)
@AutoConfigureMockMvc
@SpringBootTest
public class Junit5TestController {
	@Autowired
	MockMvc mockmvc;
	
	public Stream<DynamicTest> saveEmployee(){
		return Stream.of(DynamicTest.dynamicTest("Save data",()->{
			Employee emp = new Employee(17,"Seetha","Lead");
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String json = ow.writeValueAsString(emp);
			mockmvc.perform(MockMvcRequestBuilders.post("/api/save")
					.content(json)
					.contentType("application/json")).andExpect(MockMvcResultMatchers.status().isCreated());
			assertNotNull(emp.getId()!=null);
		
		}));
	}
	@TestFactory
	public Stream<DynamicTest> updateEmployee(){
		return Stream.of(DynamicTest.dynamicTest("Updating", ()->{
			Employee emp = new Employee();
			emp.setName("SeethaBhanuPrakash");
			emp.setRole("Technical lead");
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String json = ow.writeValueAsString(emp);
			mockmvc.perform(MockMvcRequestBuilders.put("/api/update/17").contentType("application/json").content(json)).andExpect(MockMvcResultMatchers.status().isOk());
			assertNotNull(emp.getId()!=null);
		}));
	}
	@RepeatedTest(2)
	public void getAllData() throws Exception{
			mockmvc.perform(MockMvcRequestBuilders
					.get("/api/getAllEmployees")
					.contentType("application/json"))
					.andExpect(MockMvcResultMatchers.status().isOk());
	}

}
