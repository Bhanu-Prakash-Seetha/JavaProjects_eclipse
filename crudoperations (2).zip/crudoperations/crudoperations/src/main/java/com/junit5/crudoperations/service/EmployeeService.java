package com.junit5.crudoperations.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.junit5.crudoperations.dao.EmployeeRepo;
import com.junit5.crudoperations.modal.Employee;
@Service
public class EmployeeService {
	@Autowired
	EmployeeRepo empRepo;
	
	

	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return empRepo.findAll();
	}
	public Employee insertEmployeeDetails(Employee employee) {
		// TODO Auto-generated method stub
		return empRepo.save(employee);
	}
	public Employee update(int id,Employee employee) {
		// TODO Auto-generated method stub
		Optional<Employee> existing = empRepo.findById(id);
		if(existing.isPresent()) {
		Employee newEmp = existing.get();
		newEmp.setName(employee.getName());
		newEmp.setRole(employee.getRole());
		return empRepo.save(newEmp);
		}
		return null;
		 
	}
	public Employee getById(int id, Employee employee) {
		// TODO Auto-generated method stub
		Optional<Employee> getEmp = empRepo.findById(id);
		Employee gotEmp = getEmp.get();
		return gotEmp;
	}
	public void delete(int id) {
		// TODO Auto-generated method stub
		empRepo.deleteById(id);
	}
	
	
	
	
}
