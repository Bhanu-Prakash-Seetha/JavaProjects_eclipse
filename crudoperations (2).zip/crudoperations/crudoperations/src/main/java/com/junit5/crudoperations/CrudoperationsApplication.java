package com.junit5.crudoperations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudoperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudoperationsApplication.class, args);
	}

}
