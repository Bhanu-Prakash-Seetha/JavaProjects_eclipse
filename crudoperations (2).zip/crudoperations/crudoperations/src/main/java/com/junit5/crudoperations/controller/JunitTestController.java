package com.junit5.crudoperations.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.junit5.crudoperations.modal.Employee;
import com.junit5.crudoperations.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class JunitTestController {
	@Autowired
	private EmployeeService empService;

	@GetMapping("getAllEmployees")
	public ResponseEntity<List<Employee>> getEmployees() {

		List<Employee> list = empService.getAllEmployees();
		System.out.println(list);
		return new ResponseEntity(list, HttpStatus.OK);
	}

	// saving employees details
	@PostMapping("save")
	public ResponseEntity<String> saveEmployeeDetails(@RequestBody Employee employee) {
		empService.insertEmployeeDetails(employee);
		return new ResponseEntity<>("Success", HttpStatus.CREATED);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable Integer id, @RequestBody Employee employee) {
		empService.update(id, employee);
		return new ResponseEntity("updated", HttpStatus.OK);
	}
	@GetMapping("/get/{id}")
	public Employee getById(@PathVariable int id, @RequestBody Employee employee) {
		return empService.getById(id,employee);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable int id){
		empService.delete(id);
		return new ResponseEntity<>("deleted",HttpStatus.ACCEPTED);
	}
}
