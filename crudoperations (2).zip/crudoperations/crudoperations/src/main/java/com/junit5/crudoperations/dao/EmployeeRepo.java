package com.junit5.crudoperations.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.junit5.crudoperations.modal.Employee;
@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Integer>{

}
