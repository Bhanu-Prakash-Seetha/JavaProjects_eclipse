package com.springtest.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.springtest.dao.dao.UserDao;
import com.springtest.dao.modal.Users;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@AutoConfigureMockMvc
class JunitTestonController_Dao {

	// UserDao userDao;
	ObjectWriter ow;

	@Autowired
	MockMvc mockMvc;

	//@TestFactory
	public Stream<DynamicTest> testCreationUser() {
		return Stream.of(DynamicTest.dynamicTest("Creation of new User", () -> {
			String uri = "/test/save";
			Users newUser = new Users(9, "Supriya", "Linux dev", "female");
			ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String json = ow.writeValueAsString(newUser);

			MvcResult result = mockMvc
					.perform(MockMvcRequestBuilders.post(uri).content(json)
							.contentType(MediaType.APPLICATION_JSON_VALUE))
					.andExpect(MockMvcResultMatchers.status().isCreated()).andReturn();
			int Status = result.getResponse().getStatus();

			assertThat(201).isEqualTo(Status);
		}));
	}
	@TestFactory
	public Stream<DynamicTest> getAllUsers(){
		return Stream.of(DynamicTest.dynamicTest("fetch all data", ()->{
			String uri = "/test/get";
			MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri).contentType("application/json")).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
			int statuscode = result.getResponse().getStatus();
			assertEquals(200,statuscode);
		}));
	}
}
