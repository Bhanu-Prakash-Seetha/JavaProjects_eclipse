package com.springtest.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.springtest.dao.dao.UserDao;
import com.springtest.dao.modal.Users;
import com.springtest.dao.service.UserService;
@SpringBootTest
@ExtendWith(SpringExtension.class)
class DaoPatternonTestApplicationTests {
	@Autowired
	private UserDao userDao;
	//@TestFactory
	public Stream<DynamicTest> insertionData_junit5(){
		return Stream.of(DynamicTest.dynamicTest("creation user",()->{
			Users users = new Users(2,"Prakash","ASE","male");
			userDao.save(users);
			assertNotNull(users.getUserid());
		}));
	}
	//@Test
	public void testgetAllUsers() {
		List<Users> ls = userDao.getAll();
		assertNotNull(ls);
	}
	//@Test
	public void testGetById() {
		Users user = userDao.getUserById(2);
		assertNotNull(user);
	}
	@TestFactory
	public Stream<DynamicTest> testUpdatingMethod(){
		return Stream.of(DynamicTest.dynamicTest("Updating method to test", ()->{
			Users updateUser = new Users();
			Users eUser = userDao.getUserById(3);
			if(eUser!=null) {
				eUser.setUsername("Minji");
				eUser.setUserRole("Idol");
				eUser.setGender("female");
				userDao.updateUserData(3, eUser);
				assertNotNull(eUser);
			}
		}));
	}
	@Test
	public void testDeleteById() {
		 userDao.deleteById(8);
		 assertNull(userDao.getUserById(8));
		
	}
}
