package com.springtest.dao.dao;

import java.util.List;

import com.springtest.dao.modal.Users;

public interface IUserDao {
	public void save(Users user);
	public List<Users> getAll();
	public Users updateUserData(int id,Users users);
	public Users getUserById(int id);
	public void deleteById(int id);
}
