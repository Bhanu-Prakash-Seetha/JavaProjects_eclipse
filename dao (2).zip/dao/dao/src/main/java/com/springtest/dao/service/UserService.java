package com.springtest.dao.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springtest.dao.dao.UserDao;
import com.springtest.dao.modal.Users;
@Service
public class UserService implements UserServiceDao{
	@Autowired
	private UserDao userDao;

	@Override
	@Transactional
	public void save(Users user) {
		// TODO Auto-generated method stub
		userDao.save(user);
	}

	@Override
	@Transactional
	public List<Users> getAll() {
		// TODO Auto-generated method stub
		return userDao.getAll();
	}

	@Override
	@Transactional
	public Users getUserById(int id) {
		// TODO Auto-generated method stub
		return userDao.getUserById(id);
	}

	@Override
	@Transactional
	public Users updateUserData(int id, Users users) {
		// TODO Auto-generated method stub
		return userDao.updateUserData(id, users);
	}

	@Override
	@Transactional
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		userDao.deleteById(id);
	}

}
