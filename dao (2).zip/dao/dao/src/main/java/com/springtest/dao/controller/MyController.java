package com.springtest.dao.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springtest.dao.modal.Users;
import com.springtest.dao.service.UserService;

@RestController
@RequestMapping("/test")
public class MyController {
	@Autowired
	private UserService userService;

	@GetMapping("/get")
	public ResponseEntity<List<Users>> getAllUsers() {
		userService.getAll();
		return new ResponseEntity(userService.getAll(), HttpStatus.OK);
	}

	@PostMapping("/save")
	public ResponseEntity<String> create(@RequestBody Users users) {
		userService.save(users);
		return new ResponseEntity<>("sucess creation", HttpStatus.CREATED);
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<Users> getAllUsers(@PathVariable int id) {
		userService.getUserById(id);
		return new ResponseEntity(userService.getUserById(id),HttpStatus.OK);
	}
	@PutMapping("/update/{id}")
	public ResponseEntity<Users> updateUsers(@PathVariable int id,@RequestBody Users user){
		userService.updateUserData(id, user);
		return new ResponseEntity("updated",HttpStatus.ACCEPTED);
	}
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteById(@PathVariable int id){
		userService.deleteById(id);
		return new ResponseEntity("deleted by id: "+id,HttpStatus.ACCEPTED);
	}

}
