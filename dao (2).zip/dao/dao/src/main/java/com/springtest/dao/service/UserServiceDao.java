package com.springtest.dao.service;

import java.util.List;

import com.springtest.dao.modal.Users;

public interface UserServiceDao {
	public void save(Users user);
	public List<Users> getAll();
	public Users getUserById(int id);
	public Users updateUserData(int id, Users users);
	public void deleteById(int id) ;
}
