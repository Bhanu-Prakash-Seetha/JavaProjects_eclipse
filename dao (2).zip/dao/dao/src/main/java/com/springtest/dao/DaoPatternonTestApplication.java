package com.springtest.dao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

@SpringBootApplication(exclude = HibernateJpaAutoConfiguration.class)
public class DaoPatternonTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaoPatternonTestApplication.class, args);
	}

}
