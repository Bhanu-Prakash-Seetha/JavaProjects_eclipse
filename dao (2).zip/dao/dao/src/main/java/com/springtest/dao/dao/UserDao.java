package com.springtest.dao.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springtest.dao.modal.Users;
@Repository
public class UserDao implements IUserDao{
	@Autowired
	SessionFactory sfactory;
	
	Users user = new Users();
	public UserDao(SessionFactory sfactory) {
		super();
		this.sfactory = sfactory;
	}

	@Override
	@Transactional
	public void save(Users user) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		session.save(user);
	}

	@Override
	@Transactional
	public List<Users> getAll() {
		// TODO Auto-generated method stub
		Session session= this.sfactory.getCurrentSession();
		List<Users> list = session.createQuery("From Users").list();
		System.out.println(list.toString());
		return list;
	}

	@Override
	@Transactional
	public Users updateUserData(int id, Users users) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		Users existingUser = session.get(Users.class,id);
		if(existingUser!=null) {
			existingUser.setUsername(users.getUsername());
			existingUser.setUserRole(users.getUserRole());
			existingUser.setGender(users.getGender());
			session.merge(existingUser);
			return existingUser;
		}
		
		return null;
	}

	@Override
	@Transactional
	public Users getUserById(int id) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		return session.get(Users.class,id);
	}

	@Override
	@Transactional
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		Users deleteUser = session.get(Users.class, id);
		session.delete(deleteUser);
	}

}
