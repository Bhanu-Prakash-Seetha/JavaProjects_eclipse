package com.springtest.dao.modal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table
public class Users {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer userid;
	private String username;
	private String userRole;
	private String gender;

	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Users(Integer userid, String username, String userRole, String gender) {
		super();
		this.userid = userid;
		this.username = username;
		this.userRole = userRole;
		this.gender = gender;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Users [userid=" + userid + ", username=" + username + ", userRole=" + userRole + ", gender=" + gender
				+ "]";
	}
	
}
