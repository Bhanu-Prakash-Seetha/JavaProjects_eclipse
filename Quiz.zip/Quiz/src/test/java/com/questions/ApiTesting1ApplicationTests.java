package com.questions;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTesting1ApplicationTests {

	//@Test
	void contextLoads() {
	}

}
