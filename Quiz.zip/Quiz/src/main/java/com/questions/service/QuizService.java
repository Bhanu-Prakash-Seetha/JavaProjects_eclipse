package com.questions.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.questions.modal.QuestionWrapper;
import com.questions.modal.Questions;
import com.questions.modal.Quiz;
import com.questions.modal.Responses;
import com.questions.repository.QuestionDao;
import com.questions.repository.QuizDao;
@Service
public class QuizService {
	@Autowired
	QuizDao quizDao;
	@Autowired
	QuestionDao questionDao;
	public ResponseEntity<String> createQuiz(String category, int numQ, String title) {
		// TODO Auto-generated method stub
		List<Questions> questions =questionDao.findRandomQuestionsByCategory(category,numQ);
		Quiz quiz = new Quiz();
		//quiz.setQuizid();
		quiz.setTitle(title);
		quiz.setQuestions(questions);
		quizDao.save(quiz);
		return new ResponseEntity<>("Quiz creation success",HttpStatus.CREATED);
		
		
	}
	public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(Integer id) {
		// TODO Auto-generated method stub
		Optional<Quiz> quiz =quizDao.findById(id);
		List<Questions> questionsFromDb = quiz.get().getQuestions();
		List<QuestionWrapper> questionsForUsers = new ArrayList<>();
		for(Questions q : questionsFromDb) {
			QuestionWrapper qw = new QuestionWrapper(q.getQid(),q.getQuestion(),q.getOption1(),q.getOption2(),q.getOption3(),q.getOption4());
			questionsForUsers.add(qw);
			System.out.println(qw);
			System.out.println(questionsForUsers);
		}
		return new ResponseEntity<>(questionsForUsers,HttpStatus.OK);
	}
	public ResponseEntity<Integer> submitQuiz(Integer id, List<Responses> responses) {
		// TODO Auto-generated method stub
		Quiz quiz = quizDao.findById(id).get();
		List<Questions> questions = quiz.getQuestions();
		System.out.println(questions);
		System.out.println(responses);
		int score = 0;
		int i = 0;
		for(Responses response: responses) {
			if(response.getResponse().equals(questions.get(i).getRightAnswer())) {
				
				score++;
			}
			i++;
		}
		return new ResponseEntity<>(score,HttpStatus.OK);
	}
	
	
}
