package com.questions.modal;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Quiz")
public class Quiz {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer quizid;
	private String title;
	@ManyToMany
	private List<Questions> questions;
	
	public Quiz() {
		
		// TODO Auto-generated constructor stub
	}

	public Quiz(Integer quizid, String title, List<Questions> questions) {
		super();
		this.quizid = quizid;
		this.title = title;
		this.questions = questions;
	}

	public Integer getQuizid() {
		return quizid;
	}

	public void setQuizid(Integer quizid) {
		this.quizid = quizid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Questions> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Questions> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "Quiz [quizid=" + quizid + ", title=" + title + ", questions=" + questions + "]";
	}
	
	
}
