package com.questions.modal;

public class Responses {
	private Integer qid;
	private String response;
	
	public Responses() {
		
	}
	public Responses(Integer qid, String response) {
		super();
		this.qid = qid;
		this.response = response;
	}
	public Integer getQid() {
		return qid;
	}
	public void setQid(Integer qid) {
		this.qid = qid;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "Responses [qid=" + qid + ", response=" + response + "]";
	}
	
	
}
