package io.Junittest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Junittest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
