package io.Thread.practice;

public class Producer extends Thread{
	Company c;

	public Producer(Company c) {
		super();
		this.c = c;
	}
	public void run(){
		for(int i=0;i<=30;i++){
			this.c.produce_item(i);
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
