package io.Thread.practice;

public class Consumer extends Thread{
	Company c;

	public Consumer(Company c) {
		super();
		this.c = c;
	}
	public void run(){
		for(int i=0;i<=30;i++){
			try {
				this.c.consume_item();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
