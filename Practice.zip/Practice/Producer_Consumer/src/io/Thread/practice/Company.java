package io.Thread.practice;

public class Company {
	int num;
	boolean flag = false;
	public Company() {
		
	}
	synchronized public void produce_item(int num){
		if(flag){
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
		flag=true;
		notify();
		this.num = num;
		System.out.println("Item produced : "+this.num);
	}
	synchronized public int consume_item() throws InterruptedException{
		if(!flag){
			wait();
		}
		flag=false;
		notify();
		System.out.println("Item consumed : "+this.num);
		return this.num;
		
	}
}
