package com.threadpool.Class;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Tasks implements Runnable{
	String Taskname;
	boolean flag = false;
	public Tasks(String taskname) {
		super();
		Taskname = taskname;
	}

	public String getTaskname() {
		return Taskname;
	}

	public void setTaskname(String taskname) {
		Taskname = taskname;
	}

	public void run() {
		// TODO Auto-generated method stub
		try{
			for(int i = 0;i<=10;i++){
				if(i==0){
					Date date = new Date();
					SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
					System.out.println("The name of the task is(initializing) "+Taskname+" => and time taken by task is "+sdf.format(date) + Thread.currentThread().getName());
				}else{
					Date date = new Date();
					SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
					System.out.println("The name of the task is(time of execution) "+Taskname+" => and time taken by task is "+sdf.format(date));
				}
				Thread.sleep(10000);
			}
			System.out.println(Taskname + " is completed");
			notify();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}

