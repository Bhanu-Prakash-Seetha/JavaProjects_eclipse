package com.threadpool.Class;

import java.util.concurrent.Callable;

public class UsingCallable implements Callable<Integer>{
	int taskname;
	
	public UsingCallable(int taskname) {
		super();
		this.taskname = taskname;
	}

	public Integer call() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Task "+ taskname + " is running on " +Thread.currentThread().getId());
		Thread.sleep(200);
		
		return taskname;
	}
	
}
