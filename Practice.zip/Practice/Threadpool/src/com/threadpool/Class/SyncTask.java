package com.threadpool.Class;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SyncTask {
	String Taskname;
	boolean flag = false;

	public SyncTask(String taskname, boolean flag) {
		super();
		Taskname = taskname;
		this.flag = flag;
	}

	public String getTaskname() {
		return Taskname;
	}

	public void setTaskname(String taskname) {
		Taskname = taskname;
	}

	public void initialize(String Taskname) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
		System.out.println("The name of the task is(initializing) " + Taskname + " => and time taken by task is "
				+ sdf.format(date) + Thread.currentThread().getName());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void execution(String Taskname) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
		System.out.println("The name of the task is(time of execution) " + Taskname + " => and time taken by task is "
				+ sdf.format(date));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(Taskname + " is completed");
	}
}
