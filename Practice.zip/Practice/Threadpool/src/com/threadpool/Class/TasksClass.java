package com.threadpool.Class;

public class TasksClass extends Thread{
	SyncTask st;
	String Taskname;
	public TasksClass(SyncTask st) {
		this.st=st;
	}
	
	public String getTaskname() {
		return Taskname;
	}

	public void setTaskname(String taskname) {
		Taskname = taskname;
	}

	public void run(){
		st.initialize(Taskname);;
		st.execution(Taskname);;
	}
}
