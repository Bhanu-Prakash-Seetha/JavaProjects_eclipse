package com.threadpool.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.threadpool.Class.Tasks;

public class ThreadClassTest {
	public static int Max_Th = 6;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable task1 = new Tasks("Task1");
		Runnable task2 = new Tasks("Task2");
		Runnable task3 = new Tasks("Task3");
		Runnable task4 = new Tasks("Task4");
		Runnable task5 = new Tasks("Task5");
		Runnable task6 = new Tasks("Task6");
		Runnable task7 = new Tasks("Task7");
		Runnable task8 = new Tasks("Task8");
		Runnable task9 = new Tasks("Task9");
		Runnable task10 = new Tasks("Task10");
		//Creating object for ExcecutorService class
		ExecutorService es = Executors.newFixedThreadPool(Max_Th);
		//call run method from tasks class
		es.execute(task1);
		es.execute(task2);
		es.execute(task3);
		es.execute(task4);
		es.execute(task5);
		es.execute(task6);
		es.execute(task7);
		es.execute(task8);
		es.execute(task9);
		es.execute(task10);
		es.shutdown();
	}

}
