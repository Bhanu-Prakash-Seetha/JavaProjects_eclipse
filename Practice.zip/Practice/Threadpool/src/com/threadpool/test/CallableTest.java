package com.threadpool.test;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.threadpool.Class.UsingCallable;

public class CallableTest {
	public final static int Max_Threads = 6;

	public static void main(String[] args) {
		ExecutorService es = Executors.newFixedThreadPool(Max_Threads);
		for (int i = 0; i < 20; i++) {
			Callable<Integer> callable = new UsingCallable(i);
			Future<Integer> future = es.submit(callable);
			try {
				Integer result = future.get();
				System.out.println("Task " + i + "=> result " + result);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		es.shutdown();
	}
}
