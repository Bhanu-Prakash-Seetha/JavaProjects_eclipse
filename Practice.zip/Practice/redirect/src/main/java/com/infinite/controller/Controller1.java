package com.infinite.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infinite.pojo.Credentials;

@Controller
public class Controller1 {
@RequestMapping("/index")
public String controll(){
	return "login";	
}
@RequestMapping("/login")
public String tologin(@Valid @ModelAttribute("credentials") Credentials credentials,BindingResult result){
	if(result.hasErrors()){
		System.out.println(result);
		return "login";
	}
	return "welcome";
}
}
