package io.Sync.task;

public class Taskmanager {
	int taskId=0;
	boolean f = false;
	synchronized public void initialize() throws InterruptedException {
		
		taskId++;
		System.out.println("Task is initialized "+taskId+ " "+Thread.currentThread().getName());
		notifyAll();
	}
	synchronized public void completed(int targetCount) throws InterruptedException{
		if(taskId<targetCount){
			wait();
		}
		System.out.println("Task compeleted with "+targetCount);
	}
}
