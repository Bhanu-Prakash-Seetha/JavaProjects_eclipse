package io.Sync.task;

public class Task implements Runnable {
	Taskmanager tm;
	int taskId;

	public Task(Taskmanager tm, int taskId) {
		super();
		this.tm = tm;
		this.taskId = taskId;
	}

	public void run() {
		try {
			System.out.println("Task " + taskId + " started");

			Thread.sleep(2000);

			System.out.println("Task " + taskId + " completed");
			tm.initialize();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
