package io.testclass;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.Sync.task.Task;
import io.Sync.task.Taskmanager;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecutorService executor = Executors.newFixedThreadPool(4);
		Taskmanager taskmanager = new Taskmanager();
		for(int i=0;i<6;i++){
			executor.execute(new Task(taskmanager, i));
		}
		executor.shutdown();
	}

}
