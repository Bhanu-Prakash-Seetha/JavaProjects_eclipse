package io.maths;

public class Addition extends Thread{
	Methods m;
	public Addition(Methods m) {
		super();
		this.m = m;
	}
	public void run(){
		/*for(int i=1;i<=10;i++){
			for(int j=1;j==4;j++){
				this.m.add(i, j);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
		}*/
		int a = 10;
		for(int i = 99;i<102;i++){
			for(int j=50;j>45;j--){
				try {
					this.m.add(i, j);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
	}
}
