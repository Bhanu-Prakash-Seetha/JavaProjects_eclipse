package io.maths;

public class Methods {
	int num1;
	int num2;
	public Methods(){
		
	}
	boolean cond = false;
	synchronized public void add(int num1, int num2) throws InterruptedException {
		if(cond){
			wait();
		}
		int sum = num1 + num2;
		System.out.println(Thread.currentThread().getName());
		System.out.println("Values of num1 and num2 are " + num1 + " " + num2);
		System.out.println("Addition : " + sum);
		System.out.println("-----------------------------------");
		cond = true;
		notify();
	}

	synchronized public void sub(int num1, int num2) throws InterruptedException {
		if(!cond){
			wait();
		}
		int diff = num1 - num2;
		System.out.println(Thread.currentThread().getName());
		System.out.println("Values of num1 and num2 are " + num1 + " " + num2);
		System.out.println("substraction : " + diff);
		System.out.println("-----------------------------------");
		cond=false;
		notify();
	}
}
