package io.test;

import io.maths.Addition;
import io.maths.Methods;
import io.maths.Subs;

public class Testclass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Methods m = new Methods();
		Addition a = new Addition(m);
		Subs s = new Subs(m);
		a.start();
		s.start();
	}

}
