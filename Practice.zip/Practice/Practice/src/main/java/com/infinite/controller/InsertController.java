package com.infinite.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infinite.entity.Logindata;

@Controller
public class InsertController {
@RequestMapping("/login")
	public String tologin(Model m){
	System.out.println("opening form");
	m.addAttribute("loginData",new Logindata());
		return "login";
	}
@RequestMapping("/InsertController")
public String toInsert(@Valid @ModelAttribute("loginData") Logindata logindata,BindingResult result ){
	if(result.hasErrors()){
		System.out.println("Errors detected.");
		System.out.println(result);
		return "login";
	}
	return "success";
}
}
