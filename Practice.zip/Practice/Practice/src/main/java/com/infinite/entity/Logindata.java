package com.infinite.entity;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class Logindata {
	@NotEmpty(message="this field should not be empty!")
	private String loginid;
	@Size(min=8 ,message="Atleast 8 characters expected!")
	private String pass;
	public Logindata(){
		
	}
	public Logindata(String loginid,String pass){
		this.loginid=loginid;
		this.pass=pass;
	}
	public String getLoginid() {
		return loginid;
	}
	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
}
