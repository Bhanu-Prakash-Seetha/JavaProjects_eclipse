package com.thread.classes;

public class Thread1 extends Thread{
	public void run(){
		
		for(int j=0;j<=99;j++){
		System.out.println("Welcome j : "+j);
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
}