package com.thread.classes;

public class Thread2 extends Thread{
	public void run(){
		for(int i=0;i<=99;i++){
		System.out.println("hello world i : "+i);
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
}