package com.thread.main;

import com.thread.classes.Thread1;
import com.thread.classes.Thread2;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread1 t1 = new Thread1();
		Thread2 t2 = new Thread2();
		t2.start();
		t1.start();
	}

}
