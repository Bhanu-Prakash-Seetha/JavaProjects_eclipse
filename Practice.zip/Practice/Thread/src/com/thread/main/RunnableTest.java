package com.thread.main;

import com.thread.Runnable.Runnable1;
import com.thread.Runnable.Runnable2;

class Increment {
	int count=1000;

	public synchronized void increment() {
			count++;
	}
}

public class RunnableTest {

	public static void main(String[] args) throws InterruptedException {
		Increment inc = new Increment();
		// TODO Auto-generated method stub
		Runnable obj1 = () -> {
			for (int i = 1; i <= 1000; i++) {
				inc.increment();
			}
		};
		Runnable obj2 = () -> {
			for (int i = 1; i <= 1000; i++) {
				inc.increment();
			}
		};
		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj2);
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		System.out.println(inc.count);
	}

}
