package com.game;

import java.util.Scanner;

public class Play {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tik_tak_toe game = new Tik_tak_toe();
		Scanner scanner = new Scanner(System.in);
		System.out.println();
		while (true) {
			game.printBoard();
			System.out.println("Player : " + game.currentPlayer + ", enter row(0-2) and column(0-2): ");
			int row = scanner.nextInt();
			int column = scanner.nextInt();
			if (game.placemark(row, column)) {
				if (game.checkWin()) {
					game.printBoard();
					System.out.println("Player " + game.currentPlayer + "Wins !");
					break;
				} else if (game.checkDraw()) {
					game.printBoard();
					System.out.println("Its a draw..!");
					break;
				}
				
				game.changePlayer();
			} else {
				System.out.println("This is already occupied.Try again.");
			}
		}
	}

}
