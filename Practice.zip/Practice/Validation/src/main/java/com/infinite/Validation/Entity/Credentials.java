package com.infinite.Validation.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name = "CREDENTIALS")
public class Credentials {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sno")
	private int sno;
	@Column(name = "loginid")
	@NotEmpty(message="This area should be filled..!")
	private String loginid;
	@Column(name = "password")
	@NotEmpty(message="password should not be empty.")
	@Size(min=8,message="Atleast consist 8 characters.")
	private String password;

	public Credentials() {

	}

	public Credentials(String loginid,String password) {
		this.loginid=loginid;
		this.password=password;
	}

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getLoginid() {
		return loginid;
	}

	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
