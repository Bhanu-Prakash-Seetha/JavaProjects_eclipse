package com.infinite.Validation.Controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.Validation.Entity.Credentials;

@Controller
public class MyController {
	@GetMapping("/index")
	public String home() {
		return "loginpage";
	}
	@PostMapping("/MyController")
	public String gotologin(@Valid @ModelAttribute("credentials") Credentials credentials, BindingResult result) {
		if (result.hasErrors()) {
			System.out.println(result);
			return "loginpage";
		}
		return "success";

	}
}
