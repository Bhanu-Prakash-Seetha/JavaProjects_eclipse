package com.infinite.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infinite.helper.HikariClass;

@Controller
public class LoginController {
@RequestMapping("/LoginController")
public String getLogin(HttpServletRequest request){
	Connection connection = null;
	PreparedStatement statement = null;
	//PreparedStatement statement1 = null;
	DataSource datasource = null;
	String id =request.getParameter("name");
	String pass = request.getParameter("pass");
	try{
		HikariClass hp = new HikariClass();
		datasource = hp.getdatasource();
		connection = datasource.getConnection();
		statement = connection.prepareStatement("select * from login where loginid = ? and password = ?");
		statement.setString(1, id);
		statement.setString(2, pass);
		ResultSet rs = statement.executeQuery();
		while(rs.next()){
			System.out.println("logged in successfully");
		}
	}catch(Exception e){
		e.printStackTrace();
	}
	return "successlogin";
	
}
}
