package io.springboot.thread.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsyncThreadApp {

	public static void main(String[] args) {
		SpringApplication.run(AsyncThreadApp.class, args);
	}

}
