package io.springboot.thread.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import io.springboot.thread.api.modal.Users;

public interface AyncThread_Dao extends JpaRepository<Users, Integer>{

}
