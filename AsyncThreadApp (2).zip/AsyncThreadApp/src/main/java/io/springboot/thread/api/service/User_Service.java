package io.springboot.thread.api.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import io.springboot.thread.api.modal.Users;
import io.springboot.thread.api.repository.AyncThread_Dao;

@Service
public class User_Service {
	@Autowired
	public AyncThread_Dao atd;

	@Async
	public CompletableFuture<List<Users>> saveUserData(MultipartFile file) throws Exception {
		long start = System.currentTimeMillis();
		List<Users> users = uploadDatatoDb(file);
		System.out.println("Saving List size : " + users.size() + " " + Thread.currentThread().getName());
		users = atd.saveAll(users);
		long end = System.currentTimeMillis();
		System.out.println("Total time took to save data : " + (end - start));
		return CompletableFuture.completedFuture(users);
	}

	@Async
	public CompletableFuture<List<Users>> getAllData() {
		List<Users> users = atd.findAll();
		System.out.println("The data fetched : "+users+" "+Thread.currentThread().getName());
		return CompletableFuture.completedFuture(users);
	}

	public List<Users> uploadDatatoDb(final MultipartFile file) throws Exception {
		final List<Users> user = new ArrayList<>();
		try {
			try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
				String line;
				while ((line = br.readLine()) != null) {
					String[] data = line.split(",");
					Users users = new Users();
					users.setName(data[0]);
					users.setEmail(data[1]);
					users.setGender(data[2]);
					user.add(users);
					System.out.println("Data added : " + user);
				}
				return user;
			}
		} catch (final IOException e) {
			System.out.println("Failded to parse the data from file " + e);
		}
		return null;
	}
}
