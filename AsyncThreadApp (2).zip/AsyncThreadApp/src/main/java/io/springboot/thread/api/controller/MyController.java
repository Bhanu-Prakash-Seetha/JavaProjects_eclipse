package io.springboot.thread.api.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.springboot.thread.api.modal.Users;
import io.springboot.thread.api.service.User_Service;

@RestController
@RequestMapping("api")
public class MyController {
	@Autowired 
	private User_Service us;
	
	public MyController() {
	}

	@PostMapping(value="save",consumes = {MediaType.MULTIPART_FORM_DATA_VALUE},produces ="application/json")
	public ResponseEntity saveUserData(@RequestParam(value="files") MultipartFile[] files) throws Exception {
		for(MultipartFile file : files) {
			us.saveUserData(file);
		}
		return (ResponseEntity) ResponseEntity.status(HttpStatus.CREATED).build();
	}
	
	public CompletableFuture<ResponseEntity> fetchAll(){
		return us.getAllData().thenApply(ResponseEntity::ok);	
	}
	
	@GetMapping(value="getall",produces = "application/json")
	public ResponseEntity getUsers() {
		CompletableFuture<ResponseEntity> user1 = fetchAll();
		CompletableFuture<List<Users>> user2 = us.getAllData();
		CompletableFuture<List<Users>> user3 = us.getAllData();
		CompletableFuture<List<Users>> user4 = us.getAllData();
		CompletableFuture<List<Users>> user5 = us.getAllData();
		CompletableFuture.allOf(user1,user2,user3,user4,user5).join();
		return ResponseEntity.status(HttpStatus.OK).build();
	}
	
}
