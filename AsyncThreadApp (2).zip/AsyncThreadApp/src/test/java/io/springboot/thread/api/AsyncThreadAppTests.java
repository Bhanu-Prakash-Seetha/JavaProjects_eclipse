package io.springboot.thread.api;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsyncThreadAppTests {

	//@Test
	void contextLoads() {
	}

}
