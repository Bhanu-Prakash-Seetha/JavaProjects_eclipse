package com.infinite.crudops.test.JunitonCrudops;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.infinite.crudops.test.JunitonCrudops.modal.Person;
import com.infinite.crudops.test.JunitonCrudops.repo.PersonRepo;
import com.infinite.crudops.test.JunitonCrudops.service.PersonService;

@SpringBootTest
public class JunitonCrudopsApplicationTests {
	@Autowired
	PersonRepo personrepo;
	PersonService personser;
	
	@Before
	public void setup() {
		personser = new PersonService(personrepo);
	}
	@Test
	public void testGetAllPersons() {
		Person person = new Person(2,"bhanu","bhanu06","123456");
		personrepo.save(person);
		
		List<Person> list = personser.getAllPersons();
		assertEquals(2,list.size());
		assertEquals(person.getName(),list.get(1).getName());
		
	}

}
