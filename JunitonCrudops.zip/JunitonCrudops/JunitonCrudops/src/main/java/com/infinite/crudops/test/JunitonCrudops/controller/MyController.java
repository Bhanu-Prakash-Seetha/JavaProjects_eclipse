package com.infinite.crudops.test.JunitonCrudops.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.crudops.test.JunitonCrudops.modal.Person;
import com.infinite.crudops.test.JunitonCrudops.service.PersonService;

@RestController
@RequestMapping("api")
public class MyController {
	@Autowired
	private PersonService personService;
	@GetMapping("get")
	public List<Person> getPersons() {
		List<Person> ls =  personService.getAllPersons();
		return ls;
	}
	@PostMapping("post")
	public String postData(@RequestBody Person person) {
		personService.savePersonData(person);
		return "Saved the person data";
	}
}
