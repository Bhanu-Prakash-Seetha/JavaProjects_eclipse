package com.infinite.crudops.test.JunitonCrudops.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infinite.crudops.test.JunitonCrudops.modal.Person;
@Repository
public interface PersonRepo extends JpaRepository<Person, Integer>{
	
}
