package com.infinite.crudops.test.JunitonCrudops.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.crudops.test.JunitonCrudops.modal.Person;
import com.infinite.crudops.test.JunitonCrudops.repo.PersonRepo;

@Service
public class PersonService {
	
	public PersonService() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Autowired
	private PersonRepo personRepo;

	public PersonService(PersonRepo personRepo) {
		super();
		this.personRepo = personRepo;
	}

	public void savePersonData(Person person) {
		// TODO Auto-generated method stub
		personRepo.save(person);
	}

	public List<Person> getAllPersons() {
		// TODO Auto-generated method stub
		return personRepo.findAll();
	}

}
