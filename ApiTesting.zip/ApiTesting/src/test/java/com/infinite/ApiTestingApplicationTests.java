package com.infinite;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infinite.modal.Student;

//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
public class ApiTestingApplicationTests extends AbstractTest{
	@Override
	@Before
	public void setup() {
		super.setup();
	}
	
	public ApiTestingApplicationTests() {
		// TODO Auto-generated constructor stub
	}

	@Test
	public void getStudentList() throws Exception{
		String url = "/api/fetch";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(url).accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Student[] stu = super.mapFromJson(content, Student[].class);
		assertTrue(stu.length>0);
	}
	@Test
	public void insertData() throws Exception{
		String uri = "/api/post";
		Student stu =new Student();
		stu.setStuid(5);
		stu.setName("Supriya");
		stu.setGrade("fourth");
		String inputJson = super.maptoJson(stu);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson)).andReturn();
		int status =mvcResult.getResponse().getStatus();
		assertEquals(200,status);
		String content = mvcResult.getResponse().getContentAsString();
		System.out.println(inputJson);
		System.out.println(content);
		assertEquals(content,"");
	}

}
