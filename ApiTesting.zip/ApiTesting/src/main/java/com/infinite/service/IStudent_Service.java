package com.infinite.service;

import java.util.List;

import com.infinite.modal.Student;

public interface IStudent_Service {
	public List<Student> getAll();
	public void insertStudent(Student student);
}
