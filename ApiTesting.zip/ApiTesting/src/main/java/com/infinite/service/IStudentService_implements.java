package com.infinite.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.modal.Student;
import com.infinite.repository.IStudent_Implements;
@Service
public class IStudentService_implements implements IStudent_Service{
	@Autowired IStudent_Implements isi;
	@Override
	public List<Student> getAll() {
		// TODO Auto-generated method stub
		return isi.getAll();
	}

	@Override
	public void insertStudent(Student student) {
		// TODO Auto-generated method stub
		isi.insertStudent(student);
	}

}
