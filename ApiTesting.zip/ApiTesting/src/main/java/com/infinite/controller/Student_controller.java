package com.infinite.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.modal.Student;
import com.infinite.service.IStudentService_implements;

@RestController
@RequestMapping("/api")
public class Student_controller {
	@Autowired
	IStudentService_implements issi;

	public Student_controller(IStudentService_implements issi) {
		super();
		this.issi = issi;
	}
	@GetMapping("/fetch")
	public List<Student> getAll() { 
		return this.issi.getAll();
	}
	@PostMapping("/post")
	public void insertData(@RequestBody Student student) {
		this.issi.insertStudent(student);
	}

}
