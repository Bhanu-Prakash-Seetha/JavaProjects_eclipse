package com.infinite.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infinite.modal.Student;

@Repository
public class IStudent_Implements implements IStudent {
	@Autowired
	public SessionFactory sfactory;

	public IStudent_Implements(SessionFactory sfactory) {
		super();
		this.sfactory = sfactory;
	}

	@Override
	public List<Student> getAll() {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		List<Student> ls = session.createQuery("from Student").list();
		return ls;
	}

	@Override
	public void insertStudent(Student student) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		session.save(student);
	}

}
