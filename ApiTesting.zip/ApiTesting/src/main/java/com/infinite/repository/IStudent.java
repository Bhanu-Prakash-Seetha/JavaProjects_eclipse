package com.infinite.repository;

import java.util.List;

import com.infinite.modal.Student;

public interface IStudent {
	public List<Student> getAll();
	public void insertStudent(Student student);
	
}
