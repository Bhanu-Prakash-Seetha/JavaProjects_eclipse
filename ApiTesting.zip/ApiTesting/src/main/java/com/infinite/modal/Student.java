package com.infinite.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Student")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="stuid")
	private int stuid;
	@Column(name="name")
	private String name;
	@Column(name="grade")
	private String grade;

	public Student(int stuid, String name, String grade) {
		super();
		this.stuid = stuid;
		this.name = name;
		this.grade = grade;
	}

	public Student() {
	}

	public int getStuid() {
		return stuid;
	}

	public void setStuid(int stuid) {
		this.stuid = stuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "Student [stuid=" + stuid + ", name=" + name + ", grade=" + grade + "]";
	}

}
