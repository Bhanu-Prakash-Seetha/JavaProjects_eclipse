package com.infinite.portal.dao;

import java.util.List;

import com.infinite.portal.model.UserEntity;

public interface UserEntityDao {
	public void register(UserEntity userEntity);
	List<UserEntity> getAllData();
	public UserEntity validateuser(String username, String password);
	public UserEntity updatedata(String username,String password);
	}
