package com.mockito.TestingMockito.modal;

public class Employee {
	private int id;
	private String username;
	private String gender;
	private String role;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Employee(int id, String username, String gender, String role) {
		super();
		this.id = id;
		this.username = username;
		this.gender = gender;
		this.role = role;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", username=" + username + ", gender=" + gender + ", role=" + role + "]";
	}
	

}
