package com.mockito.TestingMockito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingMockitoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingMockitoApplication.class, args);
	}

}
