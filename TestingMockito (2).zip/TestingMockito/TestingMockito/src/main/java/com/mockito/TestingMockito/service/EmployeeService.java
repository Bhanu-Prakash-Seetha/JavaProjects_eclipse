package com.mockito.TestingMockito.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.mockito.TestingMockito.dao.EmployeeRepo;
import com.mockito.TestingMockito.modal.Employee;

public class EmployeeService {
	
	@Autowired
	private EmployeeRepo empRepo;
	
	public EmployeeService(EmployeeRepo empRepo) {
		super();
		this.empRepo = empRepo;
	}

	public List<Employee> getEmployees(){
		List<Employee> list = empRepo.getAllEmployees();
		return list;
	}
	
	public String createEmployee(Employee employee) {
		empRepo.createEmployee(employee);
		return "created";
	}
	
	public Employee getEmpById(int id) {
		Employee emp = empRepo.getEmployeeById(id);
		return emp;
	}
	
	public Employee updateEmpDetails(int id,Employee emp) {
		Employee updatedEmployee = empRepo.updateEmployeeDetail(id, emp);
		return updatedEmployee;
	}
	
	public String deleteEmployeeRecord(int id) {
		empRepo.toDeleteEmployeeRecord(id);
		return null;
	}
}
