package com.mockito.TestingMockito.dao;

import java.util.List;

import com.mockito.TestingMockito.modal.Employee;

public interface EmployeeRepo {

	public List<Employee> getAllEmployees();
	public String createEmployee(Employee employee);
	public Employee updateEmployeeDetail(int id,Employee emp);
	public Employee getEmployeeById(int id);
	public String toDeleteEmployeeRecord(int id);
}
