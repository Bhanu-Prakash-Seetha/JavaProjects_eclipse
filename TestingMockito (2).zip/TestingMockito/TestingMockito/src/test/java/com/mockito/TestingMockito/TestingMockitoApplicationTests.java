package com.mockito.TestingMockito;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.mockito.TestingMockito.dao.EmployeeRepo;
import com.mockito.TestingMockito.modal.Employee;
import com.mockito.TestingMockito.service.EmployeeService;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class TestingMockitoApplicationTests {

	@Mock
	private EmployeeRepo empRepo;

	@InjectMocks
	private EmployeeService empService;

	@Test // testing getting all employee data
	public void testingGetAllEmployeesMethod() {
		Employee emp1 = new Employee(1, "bhanu", "bhanu06", "ASE");
		List<Employee> empList = new ArrayList<Employee>();
		empList.add(emp1);
		when(empRepo.getAllEmployees()).thenReturn(empList);
		List<Employee> anotherList = empService.getEmployees();
		System.out.println(anotherList);
		assertThat(anotherList).isNotNull();
	}

	@Test // testing creating new employee record
	public void testCreateEmployeeMethod() {
		Employee emp1 = new Employee(1, "fghj", "fghj", "fghj");
		when(empRepo.createEmployee(emp1)).thenReturn("created");
		String str = empService.createEmployee(emp1);
		System.out.println(str);
		assertThat("created").isEqualTo(str);
	}

	@Test // testing fetching employee record based on id
	public void testGetByIdMethod() {
		Employee emp1 = new Employee(1, "bhanu", "bhanu06", "ASE");
		Employee emp2 = new Employee(1, "prakash", "prakash06", "ASE");
		List<Employee> empList = new ArrayList<Employee>();
		empList.add(emp1);
		empList.add(emp2);
		System.out.println(empList);
		when(empRepo.getEmployeeById(emp1.getId())).thenReturn(emp1);
		Employee fetched = empService.getEmpById(emp1.getId());
		assertThat(fetched).isNotNull();
	}

	@Test // updation of employee record
	public void testUpdatingEmployeeMethod() {
		Employee emp1 = new Employee(1, "prakash", "male", "Tech lead");
		Employee emp2 = new Employee(1, "prakash", "prakash06", "ASE");
		List<Employee> empList = new ArrayList<Employee>();
		empList.add(emp1);
		empList.add(emp2);
		Employee existingEmp = empRepo.getEmployeeById(emp2.getId());
		if (existingEmp != null) {
			existingEmp.setGender("male");
			existingEmp.setRole("Tech lead");
			when(empRepo.updateEmployeeDetail(emp2.getId(), existingEmp)).thenReturn(emp1);
			Employee updatedEmp = empService.updateEmpDetails(emp2.getId(), existingEmp);
			assertThat(updatedEmp).isNotNull();
		}
	}

	@Test // testing deletion method using id
	public void testDeleteMethod() {
		Employee emp1 = new Employee(1, "bhanu", "bhanu06", "ASE");
		when(empRepo.toDeleteEmployeeRecord(emp1.getId())).thenReturn(null);
		String isnull = empService.deleteEmployeeRecord(emp1.getId());
		assertEquals(null, isnull);
	}
}
