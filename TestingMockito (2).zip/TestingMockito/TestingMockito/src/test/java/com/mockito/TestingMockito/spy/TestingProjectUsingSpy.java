package com.mockito.TestingMockito.spy;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.mockito.TestingMockito.dao.EmployeeRepo;
import com.mockito.TestingMockito.modal.Employee;
import com.mockito.TestingMockito.service.EmployeeService;

@ExtendWith(MockitoExtension.class)

public class TestingProjectUsingSpy {
	@Spy
	private EmployeeRepo empRepo;

	@InjectMocks
	private EmployeeService empService;

	Employee emp;

	@BeforeEach
	public void init() {
		emp = new Employee(1, "dfgh", "cvb", "ert");
	}

	@Test
	public void testCreateMethod_spying() {
		doReturn("created").when(empRepo).createEmployee(emp);
		String msg = empService.createEmployee(emp);
		System.out.println(msg);
		verify(empRepo, atLeast(1)).createEmployee(emp);
		assertThat(msg).isNotNull();
	}

	@Test
	public void testGetAllEmployees_usingSpy() {
		List<Employee> empList = new ArrayList<>();
		empList.add(emp);
		doReturn(empList).when(empRepo).getAllEmployees();
		List<Employee> fetched = empService.getEmployees();
		System.out.println(fetched);
		assertThat(fetched).isNotNull();
	}

	@Test
	public void testUpdateMethod_usingSpy() {
		Employee emp2 = new Employee(1, "dfgh", "male", "Engineer");
		Employee existing = empRepo.getEmployeeById(emp.getId());
		if (existing != null) {
			existing.setGender("male");
			existing.setRole("Engineer");
			doReturn(emp2).when(empRepo).updateEmployeeDetail(emp.getId(), existing);
			Employee updated = empService.updateEmpDetails(emp.getId(), existing);
			System.out.println(emp2 + " -equals- " + updated);
			assertEquals(emp2, updated);
		}
	}
	@DisplayName("deleteMethodTesting")
	@Test
	public void testDeleteMethod_usingSpy() {
		doReturn(null).when(empRepo).toDeleteEmployeeRecord(emp.getId());
		String isnull = empService.deleteEmployeeRecord(emp.getId());
		assertNull(isnull);
	}
}
